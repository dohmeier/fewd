// when the page is ready
	// make array that stores location of images in carousel 1
	
	var chicOuterwear = [		
		{
			img: "url(images/offduty/chic/one/SJ234T_RILEY_Blazer_Taupe_Front.png)",
			url: "http://shopsincerelyjules.com/collections/outerwear/products/riley-blazer",
			designer: "Sincerely Jules",
			description: "white shoes",
			price: "$129"
		},
		 {
			img: "url(images/offduty/chic/one/zara_tribal_linen_coat.png)",
			url: "http://www.zara.com/us/en/woman/outerwear/view-all/tribal-linen-coat-c719012p3521042.html",
			designer: "Zara",
			description: "",
			price: "$149"
		}
	];

	// declare index variable and set to 0
	var index = 0;
	var indexOfLastImage = chicOuterwear.length - 1;

	// when the back button is clicked
	$(".back_button").eq(0).click(function(){
		if (index === 0) {
			index = indexOfLastImage;
		} else {
			index = index - 1;
		}
		$("#outerwear1").css("background-image", chicOuterwear[index].img);
	});

	// when the next button is clicked
	$(".next_button").eq(0).click(function(){
		if (index === indexOfLastImage) {
			index = 0;
		} else {
			index = index + 1;
		}
		$("#outerwear1").css("background-image", chicOuterwear[index].img);
	});

$("#outerwear1").hoverOver({
    aniTypeIn: 'fade',
    aniTypeOut: 'fade',
    aniDurationIn: 500,
    aniDurationOut: 500,
    aniInDelay: 0,
    aniOutDelay: 0,
    contentShowHeight: 0,
    contentPushPullType: ''
    dataContent: 
});


// like carousel example, but rather than changing src to change the image changing class of div